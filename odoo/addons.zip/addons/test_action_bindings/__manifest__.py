{
    'name': "Test Action Bindings",
    'category': 'Tests',
    'data': [
        'ir.model.access.csv',
        'test_data.xml',
    ],
}
