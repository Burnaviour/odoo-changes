# -*- coding: utf-8 -*-
from odoo import models

class A(models.Model):
    _name = _description = 'tab.a'


class B(models.Model):
    _name = _description = 'tab.b'
