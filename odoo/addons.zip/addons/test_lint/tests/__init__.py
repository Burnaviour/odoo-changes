from . import test_pylint
from . import test_pofile
from . import test_ecmascript
from . import test_markers
