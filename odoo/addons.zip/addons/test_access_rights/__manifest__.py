{
    'name': 'test of access rights and rules',
    'description': "Testing of access restrictions",
    'version': '0.0.1',
    'category': 'Tests',
    'data': [
        'ir.model.access.csv',
        'security.xml',
        'data.xml',
    ],
}
